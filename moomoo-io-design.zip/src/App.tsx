import { FormEvent, useState } from "react";

export function App() {
  const [url, setUrl] = useState("https://github.com");
  const [lastOpened, setLastOpened] = useState("");

  const handleOpen = (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();

    const value = url.trim();
    if (!value) return;

    const formatted = /^https?:\/\//i.test(value) ? value : `https://${value}`;
    setLastOpened(formatted);
    window.location.assign(formatted);
  };

  return (
    <div className="min-h-screen bg-zinc-950 text-zinc-100">
      <main className="mx-auto flex min-h-screen w-full max-w-4xl flex-col justify-center px-6 py-12">
        <p className="text-sm uppercase tracking-[0.2em] text-zinc-400">GitHub Project</p>
        <h1 className="mt-3 text-4xl font-bold tracking-tight text-white md:text-5xl">Proje sifirlandi</h1>
        <p className="mt-4 max-w-2xl text-zinc-300">
          VPN veya filtre atlatma ozelligi ekleyemem, ama sade bir tarayici baslatma arayuzu
          biraktim. Adres yazip ayni sekmede acabilirsin.
        </p>

        <form onSubmit={handleOpen} className="mt-8 flex w-full flex-col gap-3 sm:flex-row">
          <input
            type="text"
            value={url}
            onChange={(event) => setUrl(event.target.value)}
            placeholder="ornek: github.com"
            className="h-12 w-full border border-zinc-700 bg-zinc-900 px-4 text-base outline-none transition focus:border-zinc-400"
          />
          <button
            type="submit"
            className="h-12 border border-zinc-300 px-6 text-sm font-semibold text-white transition hover:bg-zinc-200 hover:text-zinc-950"
          >
            Ayni Sekmede Ac
          </button>
        </form>

        <p className="mt-4 text-sm text-zinc-400">
          {lastOpened ? `Son acilan adres: ${lastOpened}` : "Henuz bir adres acilmadi."}
        </p>
      </main>
    </div>
  );
}
